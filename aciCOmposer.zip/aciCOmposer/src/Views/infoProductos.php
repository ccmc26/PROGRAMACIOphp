<?php 

use App\Models\Producto;

    $tipoAcceso = $_GET['tipoAcceso'];

    if ($tipoAcceso == 'visualizacion'){ ?>
        <h1>Informacion del producto seleccionado </h1>
        <div class="card" style="width: 18rem;">
        <!-- A l'hora de ficar lo que pertoca
            dins del src es quan funciona malament-->
        <!-- en teoria s'ha de posar 
        < ?php echo $producto -> getUrlImagen(); ?> -->
        
        <img src="<?php echo $producto->getUrlImagen(); ?>" class="card-img-top" alt="imagen_producto">
            <div class="card-body">
                <h5 class="card-title"><?php echo "{$producto->getNombre()} ({$producto->getPrecio()}€)"  ?></h5>
                <p class="card-text"><?php echo $producto->getDescripcion(); ?></p>
            </div> 
        </div>

        <?php } else if($tipoAcceso == "edicion" || $tipoAcceso == "creacion"){
            $titulo = "Informacion del producto";
            if($producto == false || is_null($producto)){
                $producto = new Producto();
            }
            if($tipoAcceso == "edicion"){
                $titulo = $titulo . " (edicion)";
            }
            else if($tipoAcceso == "creacion"){
                $titulo = $titulo . " (creacion)";
            }
?>
        <h1><?php echo $titulo?></h1>
        <div class="form-signin w-100 m-auto border p-2">
            <form class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PATH_INFO"]); ?>" method="post">
                <div class="row g-3">
                    <div class="col-12">
                        <label for="nombre" class="form-label">Nombre</label>
                        <!-- neccesiten validacio | -->
                        <!--                      v -->
                        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Introduce el nombre del producto" value="<?php echo $producto->getNombre(); ?>" required>
                    </div>

                    <div class="col-12">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <div class="input-group has-validation">
                            <!-- neccesiten validacio | -->
                            <!--                      v -->
                            <textarea class="form-control" id="descripcion" name="descripcion" placeholder="Introduce la descripción del producto" rows="3" required><?php echo $producto->getDescripcion(); ?></textarea>
                        </div>
                    </div>

                    <div class="col-12">
                        <label for="urlImagen" class="form-label">Url imagen <span class="text-muted">(Opcional)</span></label>
                        <input type="text" class="form-control" id="urlImagen" name="urlImagen" value="<?php echo $producto->getUrlImagen(); ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="precio" class="form-label">Precio</label>
                        <!-- neccesiten validacio | -->
                        <!--                      v -->
                        <input type="number" class="form-control" id="precio" name="precio" placeholder="" value="<?php echo $producto->getPrecio(); ?>" required>
                        <div class="invalid-feedback">
                            El precio es requerido.
                        </div>
                    </div>
                </div>

                <!-- guarda el tipus d'acces | -->
                <!--                         v -->
                <input type="hidden" name="tipoAcceso" value="<?php echo $tipoAcceso ?>">
                <input type="hidden" name="idProducto" value="<?php echo $producto->getId();  ?>">
                <div class="col-auto my-4 text-center">
                    <button class="btn btn-secondary mb-3" onclick="window.history.back()">Cancelar</button>
                    <button type="submit" class="btn btn-primary mb-3">Aceptar</button>
                </div>

            </form>
</div>
<?php } ?>







    







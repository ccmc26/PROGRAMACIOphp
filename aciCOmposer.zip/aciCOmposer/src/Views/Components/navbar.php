<?php 
$loggedUser = $_SESSION['usuario'];
?>

<nav class="navbar sticky-top navbar-expand-lg  border-bottom">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <img src="/assets/Eevee.png" alt="Logo" width="64" height="64" class="d-inline-block align-text-top"/>
        </a>
        <div class="navbar-nav justify-content-md-center">
            <hi class="display-6"><?php echo \app\core\Application::APP_NAME ?></hi>
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <!-- <a class="nav-link" href="/contacto">Contacto</a> -->
                <!-- <a class="nav-link" href="/registro">Registro</a> -->
                <a class="nav-link active" aria-current="page" href="/">Home</a>
                <a class="nav-link" href="/productos">Lista productos</a>
                <?php if (!is_null($loggedUser)){?>
                <a class="nav-link" href="/acercaDe">Acerca De</a>
                <?php }?>
                <?php if (is_null($loggedUser)){?>
                    <a class="nav-link" href="/login">Log in</a>
                <?php }else{?>
                    <div class="btn-group">
                        <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://robohash.org/<?php  echo $loggedUser->getUserName() ?>.png" alt="mdo" width="32" height="32" class="rounded-circle border">
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <h6 class="dropdown-header text-center">¡Hola <?php echo $loggedUser->getUserName() ?>!</h6>
                            </li>
                            <li><a class="dropdown-item" href="/perfil_usuario">Perfil</a></li>
                            <li><a class="dropdown-item" href="/logout">Log out</a></li>
                        </ul>
                    </div>
                <?php }?>
            </div>
        </div>
    </div>
</nav>
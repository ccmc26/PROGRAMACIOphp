<?php 
$loggedUser = $_SESSION['usuario'];
?>
<!-- <h1>Listado de productos</h1> -->
<h1 class="d-flex justify-content-between align-items-center mb-3">
    <span class="mb-3">Listado de productos</span>
    <?php if (!is_null($loggedUser)) { ?>
    <a type="button" class="btn btn-primary" href="/productos/0?tipoAcceso=creacion"><i class="bi bi-plus-circle-fill">Añadir producto</i></a>
    <?php } ?>
</h1>

<table class="table table-striped">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Descripción</th>
            <th scope="col">Precio</th>
            <!-- <th scope="col"></th> -->
            <?php if (!is_null($loggedUser)) { ?> 
                <th scope="col" class="text-center">Acciones</th>
            <?php } ?>
        </tr>
    </thead>
    <tbody>
        
        <?php
        for ($i = 0; $i < count($listadoProductos); $i++) {
            $productoSel = $listadoProductos[$i];
            echo  "<tr>";
            echo  "<th scope=\"row\"> {$productoSel->getId()} </th>";
            echo  "<td> {$productoSel->getNombre()}</td>";
            echo  "<td> {$productoSel->getDescripcion()}</td>";
            echo  "<td> {$productoSel->getPrecio()}</td>";
            //echo "<td><a class=\"link-opacity-10-hover\" href=\"/productos/{$productoSel->getId()}\">Detalle</a></td>";
            if (!is_null($loggedUser)) {
                echo  "<td class=\"text-center\">
                        <a type='button' class='btn btn-primary' href=\"/productos/{$productoSel->getId()}?tipoAcceso=visualizacion\">
                            <i class='bi bi-eye'></i>
                        </a>
                        <a type='button' class='btn btn-primary' href=\"/productos/{$productoSel->getId()}?tipoAcceso=edicion\">
                            <i class='bi bi-pen-fill'></i>
                        </a>
                        <button type='button' class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deleteAlert{$productoSel->getId()}'>
                            <i class='bi bi-trash'></i>
                        </button>
                    </td>";
                echo  "</tr>";

                echo '<div class="modal fade" id="deleteAlert' . $productoSel->getId() . '" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticDeleteAlert" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="staticBackdropLabel">Eliminar producto</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Va a eliminarse el producto ' . $productoSel->getNombre() . '. ¿Está segur@?
                            </div>
                            <div class="modal-footer">
                                <a type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</a>
                                <a type="button" class="btn btn-primary" href="/eliminar_productos/' . $productoSel->getId() . '">Aceptar</a>
                            </div>
                        </div>
                    </div>
                </div>';
            }
            echo  "</tr>";
        }
        ?>
    </tbody>
</table>
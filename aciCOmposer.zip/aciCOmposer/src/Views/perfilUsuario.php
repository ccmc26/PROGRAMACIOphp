<?php
$loggedUser = $_SESSION["usuario"];
?>

<h1>Datos del perfil</h1>

<div class="row mb-2">
    <div class="col-md-3">
        <img src="https://robohash.org/<?php $loggedUser->getUsername()?>.png" class="card-img-top" alt="imagen_producto">
    </div>
    <div class="col-md-9">
        <div class="form-signin w-100 m-auto border p-2">
            <form class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PATH_INFO"]); ?>" method="post">
                <div class="row g-3">
                    <div class="col-12">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" name="username" id="username" readonly class="form-control" value="<?php echo $loggedUser->getUsername() ?>" required />
                    </div>
                    <div class="col-12">
                        <label for="email" class="form-label">Email</label>
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo $loggedUser->getEmail() ?> " required/>
                    </div>
                    <div class="col-12">
                        <label for="password" class="form-label" required>Nueva password</label>
                        <input type="password" class="form-control" id="password" name="password" value="" required/>
                    </div>
                    <div class="col-12">
                        <label for="repeat_password" class="form-label" required>Repetir password</label>
                        <input type="password" class="form-control" id="repeat_password" name="repeat_password" value="" />
                    </div>
                </div>

                <input type="hidden" name="idUsuario" value="<?php echo $loggedUser->getId()?>" />
                <div class="col-auto my-4 text-center">
                    <a class="btn btn-secondary mb-3" href="/">Cancelar</a>
                    <button type="submit" class="btn btn-primary mb-3">Aceptar</button>
                </div>
            </form>
        </div>
    </div>
</div>
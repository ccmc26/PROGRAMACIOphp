<form class="needs-validation" action="<?php echo htmlspecialchars($_SERVER["PATH_INFO"]) ?>" method="post"> 
    <img class="mb-4" src="../assets/Eevee.png" alt="" width="72" height="72"> 
    <h1 class="h3 mb-3 fw-normal">Por favor, haz log in</h1>  

    <div class="form-floating">
        <input type="text" class="form-control" id="username" name="username" placeholders="Username" required/>
        <label for="username">Username</label>
    </div>
    <div class="form-floating">
        <input type="password" class="form-control" id="password" name="password" placeholders=""Password required/>
        <label for="password">Password</label>
    </div>

    <button class="w-100 btn btn-log btn-primary" type="submit">Log in</button>
    <p class="mt-5 mb-3">¿No dispones de ninguan cuenta? REGISTRATE<a class="link" href="/register"> aqui</a></p>
</form>
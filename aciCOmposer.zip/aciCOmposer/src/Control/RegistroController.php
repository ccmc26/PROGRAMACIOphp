<?php
namespace App\Control;
use App\Core\Router;
use App\Core\Route;
use App\Models\Usuario;
use App\Core\Utils;

class RegistroController{
    public function registro():string{

        $route = new Route ('registro', 'auth');
        return Router::renderView($route);
    }

    public function loginScreen(){
        $rutaAsociada = new Route('login', 'auth');
        return Router::renderView($rutaAsociada);
    }

    public function loginUser(){
        if(isset($_POST)){
            $username = $_SERVER["username"];
            $usuarioSel = Usuario::selectByUsername($_POST["username"]);
            $passwordIntroducido =  $_POST["password"];
            $passwordUsuario = "";

            if(!is_null($usuarioSel)){
                $passwordUsuario = $usuarioSel->getPassword();
            }

            if($passwordUsuario != $passwordIntroducido){
                Utils::add_alert("ERROR", "No existe el usuario $username o el password es incorrecto");
                header("Location: /login");
                exit();
            }else{
                $_SESSION["usuario"] = $usuarioSel;
                Utils::add_alert("success", "¡Bienvenid@ {$usuarioSel->getUsername()}!");
                header("Location: /");
                exit();
            }
        }
    }

    public function logout(){

        unset($_SESSION["usuario"]);
        header("Location: /");
        exit();
    }

    public function perfilUsuario(){
        $rutaAsociada = new Route('perfilUsuario', 'main');
        return Router::renderView($rutaAsociada);
    }

    public function actualizarPerfilusuario(){
        if(isset($_POST)){
            $idUsuario = $_POST["idUsuario"];
            $password = $_POST["password"];
            $repeat_password = $_POST["repeat_password"];
            if($password != $repeat_password){
                Utils::add_alert("ERROR", "Verifique correctamente el password. No son iguales");
            }else{
                $values = [
                    "username" => $_POST["username"],
                    "email" => $_POST["email"],
                    "password" => $_POST["password"],
                    "repeat_password" => $_POST["repeat_password"]
                ];
                $updateProductMessage = Usuario::update($idUsuario, $values);
                if(!$updateProductMessage && $updateProductMessage != ""){
                    Utils::add_alert("ERROR", "Error modificando los datos del perfil del usuario");
                }else{
                    $this->modificarUsuarioSesion($values);
                }
            }
        }

        header("Location: /perfil_usuario");
        exit();
    }

    public function modificarUsuarioSesion(array $values){
        $usuarioSesion = $_SESSION['usuario'];
        $usuarioSesion ->setUsername($values['username']);
        $usuarioSesion ->setEmail($values['email']);
        $usuarioSesion ->setPassword($values['password']);
        $_SESSION['usuario'] = $usuarioSesion;
    }
}
?>
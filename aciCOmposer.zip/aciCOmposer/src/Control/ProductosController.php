<?php

namespace App\Control;

use App\Models\Producto;
use App\Core\Router;
use App\Core\Route;
use App\Core\Utils;

class ProductosController{

    public function listarproductos() {
        $listaProductos = Producto::selectAll();
        $paramsView = ["listadoProductos" =>  $listaProductos];
        $rutaAsociada = new Route('productosList', 'main',  $paramsView);
        return Router::renderView($rutaAsociada);
        //Utils::console_log($listaProductos);
    }

    public function mostrarDetalleProducto($id){
        $productoSel = Producto::selectById($id);
        $paramsView = ["producto" =>  $productoSel];
        $rutaAsociada = new Route('infoProductos', 'main',  $paramsView);
        return Router::renderView($rutaAsociada);
    }

    public function eliminar($id){
        $deleteProductOk = Producto::deleteById($id);
        if(!$deleteProductOk){
            Utils::add_alert("ERROR", "Error al eliminar el producto");
        }
        return $this->listarproductos();
    }

    public function edicionProducto($id){
        if(isset($_POST) && $_SERVER["REQUEST_METHOD"] == "POST"){ 
            $tipoAcceso = $_POST["tipoAcceso"];
            if ($tipoAcceso == "edicion"){
                $idProducto = $_POST["idProducto"];
                $values = [
                    "nombre" => $_POST["nombre"],
                    "descripcion" => $_POST ["descripcion"],
                    "precio" => $_POST["precio"],
                    "urlImagen" => $_POST["urlImagen"]
                ];
                $updateProductoOk = Producto::update($idProducto, $values);
                if(!$updateProductoOk){
                Utils::add_alert("ERROR", "error al modificar el producto");
                }
            }
            else{
                $nuevoProducto = new Producto();
                $nuevoProducto->setNombre($_POST["nombre"]);
                $nuevoProducto->setDescripcion($_POST["descripcion"]);
                $nuevoProducto->setPrecio($_POST["precio"]);
                $nuevoProducto->setUrlImagen($_POST["urlImagen"]);
                $insertProductOk = Producto::create($nuevoProducto);
                if(!$insertProductOk){
                Utils::add_alert("ERROR", "error al almacenar el nuevo producto");
                }
            }
            
        }
        return $this->listarproductos();
        // return "$id producto";
    }
}
?>
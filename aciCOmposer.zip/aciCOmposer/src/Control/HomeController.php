<?php
namespace App\Control;
use App\Core\Router;
use App\Core\Route;
use App\Core\Utils;

class HomeController{
    public function home():string{
        $paramView = ["nombre"=> "Carmen", "cognom"=>"Conejero Martínez"];
        // Utils::console_log($paramView);
        $route = new Route('home', 'main', $paramView);
        return Router::renderView($route);
    }
}

?>
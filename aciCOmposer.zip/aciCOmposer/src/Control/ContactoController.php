<?php
namespace App\Control;
use App\Core\Router;
use App\Core\Route;

class ContactoController {
    public function contacto():string{

        $route= new Route('contacto', 'main');
        return Router::renderView($route);
    }
}

?>
<?php
namespace App\Control;
use App\Core\Router;
use App\Core\Route;

class AcercaDeController{
    public function acercaDe():string{

        $route = new Route('acercaDe', 'main');
        return Router::renderView($route);
    }
}
?>
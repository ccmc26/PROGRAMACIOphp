<?php
namespace App\Models;

abstract class dbModel{

    abstract static function selectById(int $id);
    abstract static function selectAll();
} 

?>
<?php
namespace App\Models;
use App\Models\dbModel;
use App\Core\Application;
use \PDO;
use App\Core\Utils;

class Producto extends dbModel {
        private int $id = 0;
        private string $nombre = "";
        private string $descripcion = "";
        private float $precio = 0;
        private string $urlImagen = "";

        public static function selectAll(){
                $db = Application::$db;
                $stmt = $db->query('SELECT * FROM productos');
                $listaProductos = $stmt->fetchAll(PDO::FETCH_CLASS, 'App\Models\Producto');
            // Utils::console_log($listaProductos);
                return $listaProductos;
        }

        public static function selectById(int $id){
                $db = Application::$db;
                $stmt = $db->prepare('SELECT * FROM productos WHERE id=?');
                $stmt->execute([$id]);
                $producto = $stmt->fetchObject('App\Models\Producto');
                return $producto;
        }

        public static function deleteById(int $id){
                $db = Application::$db;
                $stmt = $db->prepare('DELETE FROM productos WHERE ID=?');
                $deleteOK = $stmt->execute([$id]);
                return $deleteOK;
        }

        public static function create($newProduct){
                $db = Application::$db;
                $stmt = $db->prepare("INSERT INTO productos (nombre, descripcion, precio, urlImagen) VALUES(:nombre, :descripcion, :precio, :urlImagen)");
                $stmt->bindValue(':nombre', $newProduct->getNombre());
                $stmt->bindValue(':descripcion', $newProduct->getDescripcion());
                $stmt->bindValue(':precio', $newProduct->getPrecio());
                $stmt->bindValue(':urlImagen', $newProduct->getUrlImagen());
                $insertOK = $stmt->execute();
                
                return $insertOK;
        }

        public static function update(int $id, array $values){
                $db = Application::$db;
                $stmt = $db->prepare("UPDATE productos SET nombre=:nombre, descripcion=:descripcion, precio=:precio, urlImagen=:urlImagen WHERE id=:id");
                $stmt->bindValue(':nombre', $values['nombre']);
                $stmt->bindValue(':descripcion', $values['descripcion']);
                $stmt->bindValue(':precio', $values['precio']);
                $stmt->bindValue(':urlImagen', $values['urlImagen']);
                $stmt->bindValue(':id', $id);
                $updateOK = $stmt->execute();

                return $updateOK;
        }

        public function toString(){
                return "($this->id) $this->nombre $this->descripcion: $this->precio";
        }
        
        public function getId()
        {
                return $this->id;
        }
        
        public function setId(int $id)
        {
                $this->id = $id;
        }

        public function getNombre(){
                return $this->nombre;
        }

        public function setNombre(string $nombre)
        {
                $this->nombre = $nombre;

        }

        public function getDescripcion()
        {
                return $this->descripcion;
        }

        public function setDescripcion(string $descripcion)
        {
                $this->descripcion = $descripcion;

        }

        public function getPrecio()
        {
                return $this->precio;
        }

        public function setPrecio(float $precio){
                $this->precio = $precio;
                return $this;
        }

        /**
         * Get the value of urlImagen
         */
        public function getUrlImagen()
        {
                return $this->urlImagen;
        }

        /**
         * Set the value of urlImagen
         */
        public function setUrlImagen(string $urlImagen)
        {
                $this->urlImagen = $urlImagen;

                return $this;
        }
    }
?>
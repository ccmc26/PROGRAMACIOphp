<?php 
namespace App\Models;

use App\Core\Application;
use \PDOException;

class Usuario{
    private int $id = 0;
    private string $username = "";
    private string $email = "";
    private string $password = "";
    
    public static function selectByUsername($username){
        $db = Application::$db;
        $stmt = $db->prepare('SELECT * FROM usuarios WHERE username=?');
        $stmt->execute([$username]);
        $usuarioSel = $stmt->fetchObject('App\Models\Usuario');
        return $usuarioSel;
    }

    public static function create($newUser){
        $db = Application::$db;
        $stmt = $db->prepare("INSERT INTO usuarios (username, email, password) VALUES (:username, :email, :password)");
        $stmt->bindValue(':username', $newUser->getUsername());
        $stmt->bindValue(':email', $newUser->getEmail());
        $stmt->bindValue(':password', $newUser->getPassword());
        $insertOK = $stmt->execute();
        
        return $insertOK;
    }

    public static function update(int $id, array $values){
        $db = Application::$db;
        $updateOK = true;
        try{
            $stmt = $db->prepare("UPDATE usuarios SET username=:username, email=:email, password=:password WHERE id=:id");
            $stmt->bindValue(':password', $values['password']);
            $stmt->bindValue(':email', $values['email']);
            $stmt->bindValue(':username', $values['username']);
            $stmt->bindValue(':id', $id);
            $updateOK = $stmt->execute();
        }catch (PDOException $e){
            $updateOK = $e->getMessage();
        }

        return $updateOK;
}


    /**
     * Get the value of id
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of username
     */
    public function getUsername(): string
    {
        return $this->username;
    }

    /**
     * Set the value of username
     */
    public function setUsername(string $username): self
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * Set the value of email
     */
    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of password
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    /**
     * Set the value of password
     */
    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }
}
?>
<?php
namespace App\Core;
class Route{
    //tres atributos vista, layout, params
    private String $view;
    private String $layout;
    private array $params;


    public function __construct($view, $layout, $params = []){

        $this->view = $view;
        $this->layout = $layout;
        $this->params = $params;
    
    }

    public function getView(): String{
        return $this->view;
    }

    public function setView(String $view){

        $this->view = $view;
    }

    public function getLayout(): String{
        return $this->layout;
    }

    public function setLayout(String $layout){
        
        $this->layout = $layout;
    }

    public function getParams(): array{

        return $this->params;
    }

    public function setParams(array $params){
        $this->params = $params;

    }
}
?>
<?php
namespace App\Core;

class Utils{

    public static function console_log($data){
        $output = json_encode($data);

        echo "<script> console.log('{$output}');</script>";
    }

    public static function show_posible_alerts(){
        if(isset($_SESSION["alert"]) && $_SESSION["alert"] != ""){
            $alertFiles = explode('#', $_SESSION["alert"]);
            //en alertFiles[0] tenim el type
            //en alertFIles[1] tenim el message
            $type = $alertFiles[0];
            $message = $alertFiles[1];

            if($type == "error"){
                echo "<script>
                        toastr.options.positionClass = 'toast-bottom-right';
                        toastr.error('$message')
                    </script>";
            }else{
                echo "<script>
                        toastr.options.positionClass = 'toast-bottom-right';
                        toastr.info('$message')
                    </script>";
            }
            unset($_SESSION["alert"]);
        }
        
    }

    public static function add_alert($type, $message){
        $_SESSION["alert"] = "$type#$message";
    }
}
?>
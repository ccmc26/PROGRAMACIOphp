<?php
    namespace App\Core;
    use App\Core\Router;
    use PDOException;
    // use \PDO;

    class Application {
        const APP_NAME = 'SuperApp';
        private Router $ruter;
        private array $config;
        public static \PDO $db;

        public function __construct(array $config = []){
            $this->ruter = new Router();
            $this->config = $config;
            $dbConfigParams = $config['db'];
            $this->connectToDb($dbConfigParams);
            // Utils::console_log($dbConfigParams);
        }

        public function getName(): string{
            return self::APP_NAME;
        }

        public function run(){
            echo $this->ruter->resolve();
            
        }

        public function getRouter(){
            return $this->ruter;
        }

        public function connectToDb(array $configDbParams){
            try {
                self::$db = new \PDO($configDbParams['dsn'], $configDbParams['user'], $configDbParams['password']);
                self::$db->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

        public function getDb(){
            return $this->db;
        }

    }
?>
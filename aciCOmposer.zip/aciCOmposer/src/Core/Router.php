<?php

namespace App\Core;

use App\Core\Route;

class Router {
    private array $getrouters = [];
    private array $postRoutes = [];

    public function get($path, array $controlleraction){
        $path = strtolower($path);
        $this->getrouters[$path] = $controlleraction;
    }

    public function post($path, array $controlleraction){
        $path = strtolower($path);
        $this->postRoutes[$path] = $controlleraction;
    }

    public function resolve(){
        //Obtenemos el tipo de método: get o post
        $method = strtolower($_SERVER['REQUEST_METHOD']);
        //Obtenemos el path. Para evitar problemas, en caso que no exista o sea null $_SERVER['REQUEST_URI'], establecemos el path /.
        $path = $_SERVER['REQUEST_URI'] ?? '/';

        //Eliminamos los parámetros que puedan existir del path para no tenerlos en cuenta
        $position = strpos($path, '?');
        if ($position !== false) {
            $path = substr($path, 0, $position);
        }

        //Pasomos el path obtenido a minúsculas para que concuerde con los almacenados en los arrays
        $path = strtolower($path);

        //Obtenemos todos las partes del path (textos entre /)
        $pathElements = explode("/", $path);
        //Seleccionamos el último tramo que será donde está el identificador
        $ultimoPath = $pathElements[count($pathElements) - 1];
        $id = null;
        //Comprobamos que la última parte sea un número. En tal caso lo pasamos a entero y lo almacenamos en una variable $id
        //Además, reemplazamos el número por la cadena {id} para que se ajuste al posible path almacenado
        if (preg_match('/^\d*$/i', $ultimoPath, $matches)) {
            $id = intval($matches[0]);
            $path = str_replace($id, "{id}", $path);
        }

        $infoRoute = null;
        if($method == 'get' && array_key_exists($path, $this->getrouters)){
            $infoRoute = $this->getrouters[$path];
        }else if($method == 'post' && array_key_exists($path, $this->postRoutes)){
            $infoRoute = $this->postRoutes[$path];
        }

        Utils::console_log($infoRoute);

        if(!is_null($infoRoute)){
            $controlador = new $infoRoute[0]();
            $metodo = $infoRoute[1];
            $estaSecurizado = $infoRoute[2];
            if(($this->checkRouteConUsuario($estaSecurizado))){
                http_response_code(200);
                if(!is_null($id)){
                    return call_user_func(array($controlador, $metodo), $id);
                }else{
                    return call_user_func(array($controlador, $metodo));
                }
            }else if($estaSecurizado == true){
                if(!is_null($_SESSION["usuario"])){
                    http_response_code(200);
                    if(!is_null($id)){
                        return call_user_func(array($controlador, $metodo), $id);
                    }else{
                        return call_user_func(array($controlador, $metodo));
                    }
                }else{
                    http_response_code(503);
                    return "No dispone de permiso, Por favor, haga login";
                }
            }
        }else{
            http_response_code(404);
            return "Pagina no encontrada";
        }
    }

    public function checkRouteConUsuario($estaSecurizado) : bool{
        $usuarioLogged = $_SESSION["usuario"];
        // el securitzada es null
        // entre aci baix
        // |
        // v
        if(is_null($estaSecurizado)){
            return true;
        }
        // que es true
        // i esta l'usuari inicialitzat
        // aci baix
        //  |
        //  v
        if($estaSecurizado && !is_null($usuarioLogged)){
            return true;
        }
        return false;
    }

    public static function renderView(Route $route):string{
        
        $params = $route->getParams();
        foreach($params as $key => $value){
            $$key = $value;
        }
        // el $$ el que fa es ser una variable dinamica
        // o una variable variable

        // $nombre = "Carmen";
        // $apellidos = "Conejero";

        $view = $route->getView();
        ob_start();
        include_once __DIR__ . "/../Views/{$view}.php";
        $selectedview = ob_get_clean();

        $layout = $route->getLayout();
        ob_start();
        include_once __DIR__ . "/../Views/layout/{$layout}.php";
        $selectedlayout = ob_get_clean();

        $vistaFInal = str_replace('{{contenido}}', $selectedview, $selectedlayout);

        return $vistaFInal;
    }

}
?>
<?php
    error_reporting(E_ERROR | E_PARSE);
    require_once __DIR__ . '/../vendor/autoload.php';
    // require 'vendor/autoload.php';

    use App\Core\Application;
    use App\Control\HomeController;
    use App\Control\ContactoController;
    use App\Control\AcercaDeController;
    use App\Control\RegistroController;
    use App\Control\ProductosController;

    use App\Core\Utils;
    use Dotenv\Dotenv;

    $dotenv = Dotenv::createImmutable(dirname(__DIR__));
    $dotenv->load();
    

    $config = [
        'db' => [
            'dsn' => $_ENV['DB_DSN'],
            'user' => $_ENV['DB_USER'],
            'password' => $_ENV ['DB_PASSWORD'],
        ]
    ];

    session_start();

    $aplicacion = new Application($config);

    $aplicacion->getRouter()->get("/", [HomeController::class, 'home']);
    $aplicacion->getRouter()->get("/contacto", [ContactoController::class, 'contacto']);
    $aplicacion->getRouter()->get("/acercaDe", [AcercaDeController::class, 'acercaDe', true]);
    $aplicacion->getRouter()->get("/registro", [RegistroController::class, 'registro']);
    $aplicacion->getRouter()->get("/productos", [ProductosController::class, 'listarproductos']);
    $aplicacion->getRouter()->get("/productos/{id}", [ProductosController::class, 'mostrarDetalleProducto']);
    
    $aplicacion->getRouter()->get("/eliminar_productos/{id}", [ProductosController::class, 'eliminar']);
    $aplicacion->getRouter()->post("/productos/{id}", [ProductosController::class, 'edicionProducto']);
    Utils::console_log($aplicacion);

    $aplicacion->getRouter()->get("/login", [RegistroController::class, 'loginScreen']);
    $aplicacion->getRouter()->get("/logout", [RegistroController::class, 'logout']);
    $aplicacion->getRouter()->post("/login", [RegistroController::class, 'loginUser']);

    $aplicacion->getRouter()->get("/perfil_usuario", [RegistroController::class, 'perfilUsuario', true]);
    $aplicacion->getRouter()->post("/perfil_usuario",[RegistroController::class, 'actualizarPerfilUsuario', true]);

    $_SESSION["miNombre"] = "conemar";

    $aplicacion->run();

    
    Utils::show_posible_alerts();
    
?>